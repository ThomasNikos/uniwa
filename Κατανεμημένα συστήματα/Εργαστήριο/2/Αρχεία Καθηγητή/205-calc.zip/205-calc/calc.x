struct intpair {
	int a;
	int b;
};

program CALC_PROG {
		version CALC_VERS {
			int ADD(intpair) = 1;
			int SUB(intpair) = 2;
			int MUL(intpair) = 3;
			double DIV(intpair) = 4;
	} = 1;
} = 0x23451111;
