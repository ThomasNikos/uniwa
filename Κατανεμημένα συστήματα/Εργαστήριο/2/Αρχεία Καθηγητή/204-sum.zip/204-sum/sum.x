struct intpair {
	int b<5>;
};

program ADD_PROG {
		version ADD_VERS {
			intpair ADD(intpair) = 1;
	} = 1;
} = 0x23451111;
